package io.xeros.model.items;

public enum EquipmentModelType {
    NONE, FULL_HELMET, FULL_MASK, FULL_BODY
}
