package io.xeros.model.items;

public enum ContainerUpdate {
	EQUIPMENT,
	INVENTORY,
	BANK
}
